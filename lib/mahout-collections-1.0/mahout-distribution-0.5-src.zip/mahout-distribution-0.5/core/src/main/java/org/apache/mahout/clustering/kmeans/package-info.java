/**
 * This package provides an implementation of the <a href="http://en.wikipedia.org/wiki/Kmeans">k-means</a> clustering
 * algorithm.
 */
package org.apache.mahout.clustering.kmeans;